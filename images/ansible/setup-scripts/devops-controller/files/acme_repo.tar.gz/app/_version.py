<<<<<<< HEAD
__version__ = '2.46.0'
=======
__version__ = '2.45.0'
>>>>>>> fa463fc (app release playbook)
